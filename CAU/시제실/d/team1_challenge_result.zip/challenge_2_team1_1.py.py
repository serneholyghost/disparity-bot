﻿


#!/usr/bin/env python

import os
import select
import sys
import rclpy
import numpy as np
import math
import matplotlib.pyplot as plt
from rclpy.node import Node
import heapq
from geometry_msgs.msg import Twist
from rclpy.qos import QoSProfile
from time import time
from time import ctime
import csv
import threading
from geometry_msgs.msg import PoseWithCovarianceStamped
if os.name == 'nt':
    import msvcrt
else:
    import termios
    import tty

BURGER_MAX_LIN_VEL = 0.22
BURGER_MAX_ANG_VEL = 2.84
LIN_VEL_STEP_SIZE = 0.01
ANG_VEL_STEP_SIZE = 0.1

msg = """
CAU AISL EXPERIMENT
Press 'o' to start the experiment
Press 'p' to pause the experiment
Press 'q' to quit
"""
e = """
Communications Failed
"""

#Turtlebot Dynamics region
def get_key(settings):
    if os.name == 'nt':
        return msvcrt.getch().decode('utf-8')
    tty.setraw(sys.stdin.fileno())
    rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
    if rlist:
        key = sys.stdin.read(1)
    else:
        key = ''

    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key
def print_vels(target_linear_velocity, target_angular_velocity):
    print('currently:\tlinear velocity {0}\t angular velocity {1} '.format(
        target_linear_velocity,
        target_angular_velocity))
def make_simple_profile(output, input, slop):
    if input > output:
        output = min(input, output + slop)
    elif input < output:
        output = max(input, output - slop)
    else:
        output = input

    return output
def constrain(input_vel, low_bound, high_bound):
    if input_vel < low_bound:
        input_vel = low_bound
    elif input_vel > high_bound:
        input_vel = high_bound
    else:
        input_vel = input_vel

    return input_vel
def check_linear_limit_velocity(velocity):
    return constrain(velocity, -BURGER_MAX_LIN_VEL, BURGER_MAX_LIN_VEL)
def check_angular_limit_velocity(velocity):
    return constrain(velocity, -BURGER_MAX_ANG_VEL, BURGER_MAX_ANG_VEL)
 

class PathGenerator:
    def __init__(self, Waypoint, res=0.02):
        self.res = res
        self.input_waypoints = np.array(Waypoint)
        
        # 1st, 3rd try
        self.path = self.generate_path_from_waypoints(self.input_waypoints)
        
        # 2nd try
        # self.path = self.generate_path()

        self.target_wp_idx = 0
        self.len_path = len(self.path)

        self.goal_thresh = 0.02
    

    # 1st, 3rd try
    def generate_path_from_waypoints(self, waypoints):
        path = []
        turn_dir_prev = None
        dx_prev, dy_prev = 0.0, 0.0

        for i in range(len(waypoints) - 1):
            x1, y1 = waypoints[i]
            x2, y2 = waypoints[i + 1]
            dx, dy = x2 - x1, y2 - y1

            if dx == 0 or dy == 0:
                L = math.hypot(dx, dy)
                if L == 0:
                    continue
                t_vals = np.arange(0, L + self.res, self.res) / L
                xs = x1 + dx * t_vals
                ys = y1 + dy * t_vals
                segment = np.stack([xs, ys], axis=1)
                path.extend(segment.tolist())
                dx_prev, dy_prev = dx, dy
                turn_dir_prev = None

            elif abs(dx) == abs(dy):
                r = abs(dx) if dx != 0 else abs(dy)
                dtheta = self.res / r

                turn_dir_now = self.decide_turn_dir(dx_prev, dy_prev, dx, dy, turn_dir_prev)

                if abs(dy_prev) > 0:   
                    Cx, Cy = (x2, y1)
                else:                  
                    Cx, Cy = (x1, y2)

                theta1 = math.atan2(y1 - Cy, x1 - Cx)
                theta2 = math.atan2(y2 - Cy, x2 - Cx)

                if turn_dir_now == 'CCW':
                    if theta2 < theta1:
                        theta2 += 2 * math.pi
                    thetas = np.arange(theta1, theta2 + dtheta, dtheta)
                else:
                    if theta2 > theta1:
                        theta2 -= 2 * math.pi
                    thetas = np.arange(theta1, theta2 - dtheta, -dtheta)

                segment = np.array([[Cx + r * math.cos(th), Cy + r * math.sin(th)] for th in thetas])
                turn_dir_prev = turn_dir_now

                path.extend(segment)

                dx_prev, dy_prev = dx, dy
                
        return np.array(path)


    # 2nd try
    # def generate_path(self):
    #     res = 0.02  # 점 간격

    #     # 직선 구간 0→1번
    #     Waypoints = [
    #         [0.0, 0.0],    # 시작점
    #         [0.7, 0.0]     # 1번점
    #     ]
    #     path = []

    #     for i in range(len(Waypoints) - 1):
    #         start = np.array(Waypoints[i])
    #         end   = np.array(Waypoints[i + 1])
    #         distance = np.linalg.norm(end - start)
    #         num_points = max(int(distance / res), 2)
    #         xs = np.linspace(start[0], end[0], num_points)
    #         ys = np.linspace(start[1], end[1], num_points)
    #         for x, y in zip(xs, ys):
    #             path.append([x, y])

    #     # 1/2 원
    #     center_x = 0.7
    #     center_y = -0.3
    #     R = 0.3
    #     for theta in np.arange(math.pi/2, -math.pi/2  - res/R, -res/R):
    #         x = center_x + R * math.cos(theta)
    #         y = center_y + R * math.sin(theta)
    #         path.append([x, y])

    #     # 1/2원 끝 → 2번점
    #     start = np.array([0.7, -0.6])   # ¼원 끝점
    #     end   = np.array([0.2, -0.55])   # 2번점
    #     distance = np.linalg.norm(end - start)
    #     num_points = max(int(distance / res), 2)
    #     xs = np.linspace(start[0], end[0], num_points, endpoint = False)
    #     ys = np.linspace(start[1], end[1], num_points, endpoint = False)
    #     for x, y in zip(xs, ys):
    #         path.append([x, y])

    #     # 2→3번 직선
    #     start = np.array([0.2, -0.55])
    #     end   = np.array([-0.13, -0.55])
    #     distance = np.linalg.norm(end - start)
    #     num_points = max(int(distance / res), 2)
    #     xs = np.linspace(start[0], end[0], num_points)
    #     ys = np.linspace(start[1], end[1], num_points)
    #     for x, y in zip(xs, ys):
    #         path.append([x, y])

    #     # 1/4 (3번 이후)
    #     center_x = -0.13
    #     center_y = -0.87
    #     R = 0.32
    #     for theta in np.arange(math.pi / 2,   1.2 * math.pi  + res / R, res / R):
    #         x = center_x + R * math.cos(theta)
    #         y = center_y + R * math.sin(theta)
    #         path.append([x, y])

    #     # 마지막 직선1 (호 끝→직선 시작)
    #     start = np.array([-0.39, -1.06])
    #     end   = np.array([-0.27, -1.23])
    #     distance = np.linalg.norm(end - start)
    #     num_points = max(int(distance / res), 2)
    #     xs = np.linspace(start[0], end[0], num_points)
    #     ys = np.linspace(start[1], end[1], num_points)
    #     for x, y in zip(xs, ys):
    #         path.append([x, y])
            
    #     # 호 이어주기
    #     center_x = -0.03
    #     center_y = -0.8
    #     R = 0.5
    #     for theta in np.arange(1.35*math.pi,   1.51 * math.pi  + res / R, res / R):
    #         x = center_x + R * math.cos(theta)
    #         y = center_y + R * math.sin(theta)
    #         path.append([x, y])

    #     # 마지막 직선2
    #     start = np.array([0, -1.3])
    #     end   = np.array([0.3, -1.2])
    #     distance = np.linalg.norm(end - start)
    #     num_points = max(int(distance / res), 2)
    #     xs = np.linspace(start[0], end[0], num_points)
    #     ys = np.linspace(start[1], end[1], num_points)
    #     for x, y in zip(xs, ys):
    #         path.append([x, y])
        
    #     return np.array(path)

    def decide_turn_dir(self, dx_prev, dy_prev, dx_now, dy_now, turn_dir_prev):
        if turn_dir_prev is not None:
            return turn_dir_prev

        if dx_prev > 0 and dy_prev == 0:
            return 'CCW' if dy_now > 0 else 'CW'
        elif dx_prev < 0 and dy_prev == 0:
            return 'CW' if dy_now > 0 else 'CCW'
        elif dy_prev > 0 and dx_prev == 0:
            return 'CCW' if dx_now < 0 else 'CW'
        elif dy_prev < 0 and dx_prev == 0:
            return 'CW' if dx_now < 0 else 'CCW'

    def get_waypoint(self, robot_position, lookahead_dist):
        dist_to_current = np.linalg.norm(robot_position - self.path[self.target_wp_idx])
       
        if dist_to_current < self.goal_thresh and self.target_wp_idx < self.len_path - 1:
            self.target_wp_idx += 1
            
        if np.linalg.norm(robot_position - self.path[-1]) < self.goal_thresh:
            self.target_wp_idx = self.len_path - 1
            return self.path[-1], True

        # if self.target_wp_idx >= self.len_path:
        #     return self.path[-1], True

        # self.target_wp_idx = min(self.target_wp_idx, self.len_path - 1)

        for i in range(self.target_wp_idx, self.len_path):
            waypoint_pos = self.path[i]
            dist = np.linalg.norm(robot_position - waypoint_pos)

            if dist >= lookahead_dist:
                self.target_wp_idx = i
                return waypoint_pos, False

        self.target_wp_idx = self.len_path - 1
        return self.path[-1], True


################## Lateral Error & PID Controller Class ####################
# ���⿡ Tracking Error�� ����ϴ� Class�� �ۼ��ϼ���.
class PurePursuitController:
    def __init__(self, Ld):
        self.Ld = Ld

    def calculate_curv(self, robot_position, robot_yaw, desired_position):
        delta_xg = desired_position[0] - robot_position[0]
        delta_yg = desired_position[1] - robot_position[1]

        x_L = delta_xg * math.cos(robot_yaw) + delta_yg * math.sin(robot_yaw)
        y_L = -delta_xg * math.sin(robot_yaw) + delta_yg * math.cos(robot_yaw)

        if self.Ld == 0.0:
            kappa_R = 0.0
        else:
            kappa_R = 2.0 * y_L / (self.Ld ** 2)

        return kappa_R
# ���⿡ PID Controller Class�� �ۼ��ϼ���.
class PIDController:
    def __init__(self, Kp, Ki, Kd, dt=0.01):
        self.Kp = Kp
        self.Ki = Ki
        self.Kd = Kd
        self.dt = dt

        self.integral_err = 0.0
        self.prev_err = 0.0

        self.integral_limit = 1.0

    def calculate_control_output(self, err):
        self.integral_err += err * self.dt
        self.integral_err = np.clip(self.integral_err, -self.integral_limit, self.integral_limit)

        self.derivative_err = (err - self.prev_err) / self.dt

        output = (self.Kp * err) + (self.Ki * self.integral_err) + (self.Kd * self.derivative_err)

        self.prev_err = err

        return output
######################################################################################

#Sensor region
spin_thread=None
stop_event = threading.Event()
class ImuOdomSubscriber(Node):
    def __init__(self):
        super().__init__('imu_odom_subscriber')
        #print('Activate Initialization')
        # self.imu_seubscription = self.create_subscription(Imu, '/imu', self.imu_callback, 10)
        
        #print('End Initialization')
        self.mapPose_subscription = self.create_subscription(PoseWithCovarianceStamped, '/amcl_pose', self.pose_callback, 1)
        self.pose = np.array([0.0,0.0])
        self.yaw=0
        
    def euler_from_quaternion(self, z, w):
        t3 = +2.0 * (w * z )
        t4 = +1.0 - 2.0 * ( z * z)
        yaw_z = math.atan2(t3, t4)
     
        return yaw_z # in radians
            
    def pose_callback(self, msg):
        pose = msg.pose.pose.position
        orientation = msg.pose.pose.orientation
        self.pose[0] = pose.x
        self.pose[1] = pose.y
        #print(f'Position: ({pose.x:.3f}, {pose.y:.3f}, {pose.z:.3f})')
        #print(f'Orientation : ({orientation.x:.3f}, {orientation.y:.3f}, {orientation.z:.3f}, {orientation.w:.3f}')

        self.yaw = self.euler_from_quaternion(orientation.z,orientation.w)
def spin_threadfunction(node):
    while not stop_event.is_set():
        rclpy.spin_once(node, timeout_sec=0.01)
    rclpy.shutdown()

def main():
    settings = None
    if os.name != 'nt':
        settings = termios.tcgetattr(sys.stdin)
    rclpy.init()

    qos = QoSProfile(depth=10)
    imuodom_subscriber = ImuOdomSubscriber()
    node = rclpy.create_node('sine_turtlebot')
    
    pub = node.create_publisher(Twist, 'cmd_vel', qos)

    spin_thread = threading.Thread(target=spin_threadfunction ,args=(imuodom_subscriber,))
    spin_thread.start()

    target_linear_velocity = 0.0
    target_angular_velocity = 0.0
    control_linear_velocity = 0.0
    control_angular_velocity = 0.0


    ################################ �л����� �ۼ��� �κ� #################################
    ################################ Reference Path ���� #################################
    # ���� ���ǵ� Reference Path Class�� ȣ���Ͽ��� Reference Path�� �����ϵ��� �ڵ带 �ۼ��ϼ���.
    

    ######################## Waypoint�� Obstacle ��ǥ�� �Է��ϼ��� ########################
    
    # 1st try
    wp_1  = np.array([0.0, 0.0])
    wp_2  = wp_1 + np.array([0.7,     0.0])
    wp_3  = wp_2 + np.array([0.2,    -0.2])
    wp_4  = wp_3 + np.array([0.0,    -0.18])
    wp_5  = wp_4 + np.array([-0.2,   -0.2])
    wp_6  = wp_5 + np.array([-0.9,    0.0])
    wp_7  = wp_6 + np.array([-0.15,  -0.15])
    wp_8  = wp_7 + np.array([0.0,    -0.45])
    wp_9  = wp_8 + np.array([0.15,   -0.15])
    wp_10 = wp_9 + np.array([1.0,     0.0])
    
    # 3rd try
    # wp_2  = wp_1  + np.array([ 0.70,    0.00])
    # wp_3  = wp_2  + np.array([ 0.20,   -0.20])
    # wp_4  = wp_3  + np.array([ 0.00,   -0.10])
    # wp_5  = wp_4  + np.array([-0.20,   -0.20])
    # wp_6  = wp_5  + np.array([-0.50,    0.00])
    # wp_7  = wp_6  + np.array([-0.10,   -0.10])
    # wp_8  = wp_7  + np.array([ 0.10,   -0.10])
    # wp_9  = wp_8  + np.array([ 0.60,    0.00])
    # wp_10 = wp_9  + np.array([ 0.20,   -0.20])
    # wp_11 = wp_10 + np.array([-0.20,   -0.20])
    # wp_12 = wp_11 + np.array([-0.60,   -0.00])
    
    # 1st try
    Waypoint = [wp_1, wp_2, wp_3, wp_4, wp_5, wp_6, wp_7, wp_8, wp_9, wp_10]
    
    # 2nd try
    # Waypoint = []

    # 3rd try
    # Waypoint = [wp_1, wp_2, wp_3, wp_4, wp_5, wp_6, wp_7, wp_8, wp_9, wp_10, wp_11, wp_12]
    
    
    path_generator = PathGenerator(Waypoint, res=0.02)

    ########################## PID Controller Initialization #############################
    # ���� ���ǵ� PID Controller�� ȣ���Ͽ��� PID Controller�� �ʱ�ȭ�ϼ���.
    lookahead_distance = 0.25
    constant_linear_velocity = 0.08

    pure_pursuit = PurePursuitController(Ld=lookahead_distance)

    KP = 0.8
    KI = 0.05
    KD = 0.05
    DT = 0.01

    pid_controller = PIDController(Kp=KP, Ki=KI, Kd=KD, dt=DT)

    ######################################################################################

    try:
        print(msg)
        start = False
        
        startTime =time()
        prev_time = time()
        with open('test.csv',mode='w', newline='') as file:
            writer= csv.writer(file)
            writer.writerow(['starttime',
                             'time',
                             'desired position',
                             'present position',
                             'present heading angle',
                             'target_wp_idx',
                             'ctrl_ref_omg',
                             'pid_error',
                             'dist_to_goal',
                             'duration',
                             'cmd_lin_vel',
                             'cmd_ang_vel']) ######## ������� ���� ����!
            while True:
                key = get_key(settings)

                if key == 'o':
                    print("Starting")
                    start = True
                    startTime =time()
                    prev_yaw = imuodom_subscriber.yaw
                    prev_time = time()

                elif key == 'p':
                    print("Paused by user input.")
                    start = False
                    twist = Twist()
                    twist.linear.x = 0.0
                    twist.angular.z = 0.0
                    pub.publish(twist)

                elif key == 'q':
                    print("Quitting...")
                    stop_event.set()
                    return
                
                if start:
                    now_time = time()
                    dt = now_time - prev_time
                    if dt <=1e-6:
                        dt=1e-3
                    prev_time = now_time
                    pid_controller.dt = dt
                    
                    robot_position = np.array([imuodom_subscriber.pose[0], imuodom_subscriber.pose[1]])
                    robot_yaw = imuodom_subscriber.yaw
                    
                    ################################ �л����� �ۼ��� �κ� #################################
                    desired_waypoint, path_complete = path_generator.get_waypoint(robot_position, lookahead_distance)
                    desired_position = desired_waypoint     ###### ���� ��Ʋ���� ��ǥ�� �ϴ� Desired Waypoint Position
                    
                    theta_dot_d = 0.0
                    error_input = 0.0
                    
                    if path_complete:
                        target_linear_velocity = 0.0
                        target_angular_velocity = 0.0
                    else:
                        kappa_R = pure_pursuit.calculate_curv(robot_position, robot_yaw, desired_position)
                        theta_dot_d = constant_linear_velocity * kappa_R

                        dyaw = math.atan2(math.sin(robot_yaw - prev_yaw), math.cos(robot_yaw - prev_yaw))
                        yaw_rate_meas = dyaw / dt
                        prev_yaw = robot_yaw
                        
                        error_input = theta_dot_d - yaw_rate_meas
                        angular_cmd_pid = pid_controller.calculate_control_output(error_input)

                    #################### Lateral Error & PID Controller Generation ###################
                    # ���� ���ǵ� Tracking Error Class�� ȣ���Ͽ��� Error�� Output���� �ϴ� �ڵ带 �ۼ��ϼ���.

                    # Output���� ���� Error�� ������ ���� ���ǵ� PID Controller�� ȣ���Ͽ��� ��������� �����ϴ� �ڵ带 �ۼ��ϼ���.

                        target_linear_velocity = check_linear_limit_velocity(constant_linear_velocity)   ####### ���ӵ� ������� (��ӵ� ������ �ΰ��ϼ���)
                        target_angular_velocity = check_angular_limit_velocity(angular_cmd_pid)           ####### ���ӵ� �������
                    ##################################################################################
                    
                    #csv ����
                    writer.writerow([
                        startTime,
                        time(),
                        str(desired_position),
                        str(robot_position),
                        str(robot_yaw),
                        path_generator.target_wp_idx,
                        theta_dot_d,
                        error_input,
                        np.linalg.norm(robot_position - desired_position),
                        time() - startTime,
                        float(control_linear_velocity),
                        float(control_angular_velocity)
                    ])

                    
                    print(f"position : {robot_position}, yaw : {str(robot_yaw)}, desired : {desired_position}, controll : {(target_linear_velocity,target_angular_velocity)}")

                    # �ӵ� �������� �� ���� ���� ����
                    control_linear_velocity = make_simple_profile(control_linear_velocity, target_linear_velocity, (LIN_VEL_STEP_SIZE / 2.0))
                    control_angular_velocity = make_simple_profile(control_angular_velocity, target_angular_velocity, (ANG_VEL_STEP_SIZE / 2.0))

                    MIN_LIN_VEL = 0.03
                    if target_linear_velocity > 0.0:  # ���� ���� ���� �ּ� �ӵ� ����
                        control_linear_velocity = max(control_linear_velocity, MIN_LIN_VEL)
                    else:
                        control_linear_velocity = 0.0

                    twist = Twist()
                    twist.linear.x = float(control_linear_velocity)
                    twist.angular.z = float(control_angular_velocity)
                    pub.publish(twist)

    except Exception as ex:
        print(ex)

    finally:
        twist = Twist()
        twist.linear.x = 0.0
        twist.angular.z = 0.0
        pub.publish(twist)

        if os.name != 'nt':
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)

if __name__ == '__main__':
    main()
